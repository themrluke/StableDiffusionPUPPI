//Numpy array shape [4]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 4

#ifndef B14_H_
#define B14_H_

#ifndef __SYNTHESIS__
bias14_t b14[4];
#else
bias14_t b14[4] = {3.196062, 1.420652, 1.356042, 1.773608};
#endif

#endif
