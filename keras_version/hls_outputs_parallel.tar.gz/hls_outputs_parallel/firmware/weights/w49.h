//Numpy array shape [4, 1]
//Min -0.383119881153
//Max 0.323755234480
//Number of zeros 0

#ifndef W49_H_
#define W49_H_

#ifndef __SYNTHESIS__
emb1_weight_t w49[4];
#else
emb1_weight_t w49[4] = {-0.383120, -0.332457, 0.323755, -0.280065};
#endif

#endif
