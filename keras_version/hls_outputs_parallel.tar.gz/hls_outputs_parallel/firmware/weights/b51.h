//Numpy array shape [4]
//Min -0.173049181700
//Max 0.015171887353
//Number of zeros 0

#ifndef B51_H_
#define B51_H_

#ifndef __SYNTHESIS__
emb5_bias_t b51[4];
#else
emb5_bias_t b51[4] = {-0.173049, -0.008855, -0.050290, 0.015172};
#endif

#endif
