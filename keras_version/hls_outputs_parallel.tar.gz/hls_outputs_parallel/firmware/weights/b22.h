//Numpy array shape [8]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 8

#ifndef B22_H_
#define B22_H_

#ifndef __SYNTHESIS__
bias22_t b22[8];
#else
bias22_t b22[8] = {0.258086, 1.032419, 1.284907, -0.927241, -0.193200, 1.240626, -0.210874, -0.730264};
#endif

#endif
