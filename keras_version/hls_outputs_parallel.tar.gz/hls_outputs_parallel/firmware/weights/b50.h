//Numpy array shape [4]
//Min 0.028976731002
//Max 0.140178784728
//Number of zeros 0

#ifndef B50_H_
#define B50_H_

#ifndef __SYNTHESIS__
emb4_bias_t b50[4];
#else
emb4_bias_t b50[4] = {0.140179, 0.040636, 0.029219, 0.028977};
#endif

#endif
