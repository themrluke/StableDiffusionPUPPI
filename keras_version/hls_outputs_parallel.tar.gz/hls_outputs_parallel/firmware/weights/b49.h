//Numpy array shape [1]
//Min -0.367967009544
//Max -0.367967009544
//Number of zeros 0

#ifndef B49_H_
#define B49_H_

#ifndef __SYNTHESIS__
emb1_bias_t b49[1];
#else
emb1_bias_t b49[1] = {-0.367967};
#endif

#endif
