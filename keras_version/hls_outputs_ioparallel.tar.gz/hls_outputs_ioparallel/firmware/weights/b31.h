//Numpy array shape [4]
//Min -0.001735041966
//Max 0.002783009317
//Number of zeros 0

#ifndef B31_H_
#define B31_H_

#ifndef __SYNTHESIS__
convu1_1_bias_t b31[4];
#else
convu1_1_bias_t b31[4] = {0.243243, -0.060502, 0.186960, 0.596651};
#endif

#endif
