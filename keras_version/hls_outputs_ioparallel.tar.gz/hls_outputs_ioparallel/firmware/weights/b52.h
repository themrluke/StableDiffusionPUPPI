//Numpy array shape [1]
//Min 0.051097225398
//Max 0.051097225398
//Number of zeros 0

#ifndef B52_H_
#define B52_H_

#ifndef __SYNTHESIS__
out_bias_t b52[1];
#else
out_bias_t b52[1] = {0.051097};
#endif

#endif
