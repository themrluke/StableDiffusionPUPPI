//Numpy array shape [4]
//Min -0.006108502857
//Max 0.002094537951
//Number of zeros 0

#ifndef B31_H_
#define B31_H_

#ifndef __SYNTHESIS__
convu1_1_bias_t b31[4];
#else
convu1_1_bias_t b31[4] = {-0.553251, 0.081102, 0.402421, 0.914831};
#endif

#endif
