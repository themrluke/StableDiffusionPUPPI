//Numpy array shape [4]
//Min -0.181554049253
//Max 0.102566637099
//Number of zeros 0

#ifndef B51_H_
#define B51_H_

#ifndef __SYNTHESIS__
emb5_bias_t b51[4];
#else
emb5_bias_t b51[4] = {0.037922, -0.181554, -0.012974, 0.102567};
#endif

#endif
