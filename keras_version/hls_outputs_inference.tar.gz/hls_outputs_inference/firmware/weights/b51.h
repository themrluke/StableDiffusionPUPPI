//Numpy array shape [4]
//Min -0.048907421529
//Max 0.079567663372
//Number of zeros 0

#ifndef B51_H_
#define B51_H_

#ifndef __SYNTHESIS__
emb5_bias_t b51[4];
#else
emb5_bias_t b51[4] = {0.009375, -0.048907, 0.017060, 0.079568};
#endif

#endif
