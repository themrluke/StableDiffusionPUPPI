//Numpy array shape [4, 1]
//Min -0.133043304086
//Max 0.539869725704
//Number of zeros 0

#ifndef W49_H_
#define W49_H_

#ifndef __SYNTHESIS__
emb1_weight_t w49[4];
#else
emb1_weight_t w49[4] = {-0.133043, -0.075134, 0.539870, 0.339244};
#endif

#endif
