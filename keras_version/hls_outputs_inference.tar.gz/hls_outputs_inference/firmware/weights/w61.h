//Numpy array shape [1, 1, 4, 1]
//Min -0.861152470112
//Max 0.644945859909
//Number of zeros 0

#ifndef W61_H_
#define W61_H_

#ifndef __SYNTHESIS__
out_weight_t w61[4];
#else
out_weight_t w61[4] = {0.616805, 0.280681, 0.644946, -0.861152};
#endif

#endif
