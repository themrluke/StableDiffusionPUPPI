//Numpy array shape [1, 1, 4, 1]
//Min -0.661548674107
//Max 0.738496184349
//Number of zeros 0

#ifndef W61_H_
#define W61_H_

#ifndef __SYNTHESIS__
out_weight_t w61[4];
#else
out_weight_t w61[4] = {0.680034, 0.323270, 0.738496, -0.661549};
#endif

#endif
