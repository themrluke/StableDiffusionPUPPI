//Numpy array shape [1]
//Min 0.150939762592
//Max 0.150939762592
//Number of zeros 0

#ifndef B61_H_
#define B61_H_

#ifndef __SYNTHESIS__
out_bias_t b61[1];
#else
out_bias_t b61[1] = {0.150940};
#endif

#endif
