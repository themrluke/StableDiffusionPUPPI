//Numpy array shape [4]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 4

#ifndef B10_H_
#define B10_H_

#ifndef __SYNTHESIS__
bias10_t b10[4];
#else
bias10_t b10[4] = {-0.567242, 0.659182, 1.144823, 1.205718};
#endif

#endif
