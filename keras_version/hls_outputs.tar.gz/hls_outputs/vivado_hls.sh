
export PATH=/software/CAD/Xilinx/2019.2/Vivado/2019.2/bin:$PATH
export LD_LIBRARY_PATH=/software/CAD/Xilinx/2019.2/Vivado/2019.2/lib:$LD_LIBRARY_PATH
source /software/CAD/Xilinx/2019.2/Vivado/2019.2/settings64.sh
export LC_ALL=en_US.utf-8
export LANG=en_US.utf-8
