//Numpy array shape [1]
//Min -0.029438327998
//Max -0.029438327998
//Number of zeros 0

#ifndef B49_H_
#define B49_H_

#ifndef __SYNTHESIS__
emb1_bias_t b49[1];
#else
emb1_bias_t b49[1] = {-0.029438};
#endif

#endif
