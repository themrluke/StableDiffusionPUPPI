//Numpy array shape [4]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 4

#ifndef B14_H_
#define B14_H_

#ifndef __SYNTHESIS__
bias14_t b14[4];
#else
bias14_t b14[4] = {0.222973, -0.003053, -0.239521, 0.235145};
#endif

#endif
