//Numpy array shape [4]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 4

#ifndef B14_H_
#define B14_H_

#ifndef __SYNTHESIS__
bias14_t b14[4];
#else
bias14_t b14[4] = {0.223066, -0.003203, -0.239444, 0.234962};
#endif

#endif
