//Numpy array shape [1, 1, 4, 1]
//Min -0.937951445580
//Max 0.566924393177
//Number of zeros 0

#ifndef W61_H_
#define W61_H_

#ifndef __SYNTHESIS__
out_weight_t w61[4];
#else
out_weight_t w61[4] = {0.550954, 0.193919, 0.566924, -0.937951};
#endif

#endif
