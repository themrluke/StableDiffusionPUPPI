//Numpy array shape [1]
//Min 0.080889575183
//Max 0.080889575183
//Number of zeros 0

#ifndef B61_H_
#define B61_H_

#ifndef __SYNTHESIS__
out_bias_t b61[1];
#else
out_bias_t b61[1] = {0.080890};
#endif

#endif
