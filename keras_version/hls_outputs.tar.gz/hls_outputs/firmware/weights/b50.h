//Numpy array shape [1]
//Min 0.002491167048
//Max 0.002491167048
//Number of zeros 0

#ifndef B50_H_
#define B50_H_

#ifndef __SYNTHESIS__
emb1_bias_t b50[1];
#else
emb1_bias_t b50[1] = {0.002491};
#endif

#endif
