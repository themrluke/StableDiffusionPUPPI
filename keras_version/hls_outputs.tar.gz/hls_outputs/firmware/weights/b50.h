//Numpy array shape [1]
//Min 0.002495125867
//Max 0.002495125867
//Number of zeros 0

#ifndef B50_H_
#define B50_H_

#ifndef __SYNTHESIS__
emb1_bias_t b50[1];
#else
emb1_bias_t b50[1] = {0.002495};
#endif

#endif
