//Numpy array shape [4]
//Min -0.000006132972
//Max 0.000006352904
//Number of zeros 0

#ifndef B31_H_
#define B31_H_

#ifndef __SYNTHESIS__
convu1_1_bias_t b31[4];
#else
convu1_1_bias_t b31[4] = {0.045149, -0.310729, 0.049925, 0.137295};
#endif

#endif
