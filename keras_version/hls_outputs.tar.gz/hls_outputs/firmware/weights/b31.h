//Numpy array shape [4]
//Min -0.000212104584
//Max 0.000300473621
//Number of zeros 0

#ifndef B31_H_
#define B31_H_

#ifndef __SYNTHESIS__
convu1_1_bias_t b31[4];
#else
convu1_1_bias_t b31[4] = {-0.264151, -0.347518, -0.213022, 0.307743};
#endif

#endif
