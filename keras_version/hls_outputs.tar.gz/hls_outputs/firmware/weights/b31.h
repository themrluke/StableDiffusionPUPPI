//Numpy array shape [4]
//Min -0.000005043881
//Max 0.000011234707
//Number of zeros 0

#ifndef B31_H_
#define B31_H_

#ifndef __SYNTHESIS__
convu1_1_bias_t b31[4];
#else
convu1_1_bias_t b31[4] = {0.045248, -0.310741, 0.049874, 0.137376};
#endif

#endif
