//Numpy array shape [4]
//Min -0.000013374321
//Max 0.000003014823
//Number of zeros 0

#ifndef B31_H_
#define B31_H_

#ifndef __SYNTHESIS__
convu1_1_bias_t b31[4];
#else
convu1_1_bias_t b31[4] = {0.045192, -0.310767, 0.049977, 0.137342};
#endif

#endif
