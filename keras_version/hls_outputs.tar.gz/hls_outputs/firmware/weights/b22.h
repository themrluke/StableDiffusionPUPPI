//Numpy array shape [8]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 8

#ifndef B22_H_
#define B22_H_

#ifndef __SYNTHESIS__
bias22_t b22[8];
#else
bias22_t b22[8] = {0.879529, 1.230186, 0.007909, 0.220039, -0.442834, -0.318063, -0.606967, 0.323036};
#endif

#endif
