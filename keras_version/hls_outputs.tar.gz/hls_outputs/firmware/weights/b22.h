//Numpy array shape [8]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 8

#ifndef B22_H_
#define B22_H_

#ifndef __SYNTHESIS__
bias22_t b22[8];
#else
bias22_t b22[8] = {0.879585, 1.230071, 0.008043, 0.219988, -0.442911, -0.318202, -0.607002, 0.323062};
#endif

#endif
