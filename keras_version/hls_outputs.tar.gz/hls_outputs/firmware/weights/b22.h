//Numpy array shape [8]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 8

#ifndef B22_H_
#define B22_H_

#ifndef __SYNTHESIS__
bias22_t b22[8];
#else
bias22_t b22[8] = {0.303709, -0.280959, 0.718138, -1.293784, 0.621218, -0.006012, -0.354133, 0.446965};
#endif

#endif
