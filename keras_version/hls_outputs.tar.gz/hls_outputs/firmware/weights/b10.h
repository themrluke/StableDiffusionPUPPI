//Numpy array shape [4]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 4

#ifndef B10_H_
#define B10_H_

#ifndef __SYNTHESIS__
bias10_t b10[4];
#else
bias10_t b10[4] = {-0.151214, -0.217545, -0.061448, 0.273048};
#endif

#endif
