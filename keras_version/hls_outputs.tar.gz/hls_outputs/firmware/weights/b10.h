//Numpy array shape [4]
//Min 0.000000000000
//Max 0.000000000000
//Number of zeros 4

#ifndef B10_H_
#define B10_H_

#ifndef __SYNTHESIS__
bias10_t b10[4];
#else
bias10_t b10[4] = {-0.458374, 0.043556, 0.002940, 0.556452};
#endif

#endif
