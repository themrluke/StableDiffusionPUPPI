//Numpy array shape [1]
//Min 0.006001553033
//Max 0.006001553033
//Number of zeros 0

#ifndef B62_H_
#define B62_H_

#ifndef __SYNTHESIS__
out_bias_t b62[1];
#else
out_bias_t b62[1] = {0.006002};
#endif

#endif
