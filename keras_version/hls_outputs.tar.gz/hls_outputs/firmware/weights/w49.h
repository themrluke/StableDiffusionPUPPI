//Numpy array shape [4, 1]
//Min -0.453041791916
//Max 0.081626117229
//Number of zeros 0

#ifndef W49_H_
#define W49_H_

#ifndef __SYNTHESIS__
emb1_weight_t w49[4];
#else
emb1_weight_t w49[4] = {-0.398080, -0.453042, -0.450770, 0.081626};
#endif

#endif
