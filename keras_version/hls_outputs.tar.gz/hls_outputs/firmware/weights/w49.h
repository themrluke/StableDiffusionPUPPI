//Numpy array shape [4, 1]
//Min -0.582428872585
//Max 0.112933397293
//Number of zeros 0

#ifndef W49_H_
#define W49_H_

#ifndef __SYNTHESIS__
emb1_weight_t w49[4];
#else
emb1_weight_t w49[4] = {-0.548038, -0.582429, -0.383901, 0.112933};
#endif

#endif
