//Numpy array shape [4]
//Min -0.003538556863
//Max 0.003815054428
//Number of zeros 0

#ifndef B51_H_
#define B51_H_

#ifndef __SYNTHESIS__
emb4_bias_t b51[4];
#else
emb4_bias_t b51[4] = {0.003214, -0.003539, 0.003815, -0.001535};
#endif

#endif
