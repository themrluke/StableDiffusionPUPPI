
# Update the PATH and LD_LIBRARY_PATH to include Vitis HLS
export PATH=/opt/Xilinx/Vitis_HLS/2024.1/bin:$PATH
export LD_LIBRARY_PATH=/opt/Xilinx/Vitis_HLS/2024.1/lib:$LD_LIBRARY_PATH
source /opt/Xilinx/Vitis_HLS/2024.1/settings64.sh
export LC_ALL=en_US.utf-8
export LANG=en_US.utf-8
